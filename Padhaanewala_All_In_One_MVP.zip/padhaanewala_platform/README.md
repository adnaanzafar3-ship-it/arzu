# Padhaanewala — Runnable Platform MVP

Built from the supplied Padhaanewala Master Website Development Specification.

## Run with Docker

Install Docker Desktop, then:

```bash
docker compose up --build
```

Open:

- Website: http://localhost:3000
- Admin: http://localhost:3000/admin
- API docs: http://localhost:8000/docs
- API health: http://localhost:8000/api/v1/health

## Demo admin

Email: `admin@padhaanewala.in`
Password: `admin123`

Change these credentials and JWT_SECRET before production.

## Included

- Gen-Z responsive Next.js frontend
- FastAPI REST backend
- PostgreSQL database
- College database + search
- Course database
- Scholarship database
- AI college predictor foundation
- Admission enquiry → CRM lead
- Admin login
- Admin dashboard/statistics/leads
- Seed data
- Docker deployment
- API documentation through FastAPI/Swagger

## Production hardening still required

This is a runnable MVP/scaffold, not a finished production deployment. Before collecting real student documents or sensitive information, add:

- production password hashing/auth flows
- secure HttpOnly cookies or a hardened token strategy
- 2FA
- rate limiting
- CSRF protection where applicable
- strict CORS
- object storage for images/documents
- encryption and access controls for sensitive files
- database migrations (Alembic)
- automated backups
- email/SMS/WhatsApp provider
- real AI provider behind the FastAPI backend
- analytics/consent implementation
- moderation workflows
- full RBAC
- tests and monitoring
- HTTPS/domain deployment
- verified real college/course/scholarship data

The supplied specification explicitly requires these production concerns and a scalable architecture.
