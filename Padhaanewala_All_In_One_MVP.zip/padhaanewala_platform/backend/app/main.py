import os, uuid, datetime as dt
from typing import Optional
from fastapi import FastAPI, Depends, HTTPException, Header
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, EmailStr
from sqlalchemy import create_engine, String, Integer, Float, Text, Boolean, DateTime, select, or_
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, Session, sessionmaker
from jose import jwt, JWTError
from passlib.context import CryptContext

DATABASE_URL = os.getenv("DATABASE_URL","sqlite:///./padhaanewala.db")
JWT_SECRET = os.getenv("JWT_SECRET","dev-secret")
ADMIN_EMAIL = os.getenv("ADMIN_EMAIL","admin@padhaanewala.in")
ADMIN_PASSWORD = os.getenv("ADMIN_PASSWORD","admin123")

engine = create_engine(DATABASE_URL, pool_pre_ping=True)
SessionLocal = sessionmaker(bind=engine, expire_on_commit=False)
pwd = CryptContext(schemes=["bcrypt"], deprecated="auto")

class Base(DeclarativeBase): pass

class College(Base):
    __tablename__="colleges"
    id: Mapped[str] = mapped_column(String(40), primary_key=True)
    name: Mapped[str] = mapped_column(String(200), index=True)
    city: Mapped[str] = mapped_column(String(100), index=True)
    state: Mapped[str] = mapped_column(String(100), index=True)
    course: Mapped[str] = mapped_column(String(100), index=True)
    fees: Mapped[float] = mapped_column(Float, default=0)
    rating: Mapped[float] = mapped_column(Float, default=0)
    college_type: Mapped[str] = mapped_column(String(40), default="Private")
    hostel: Mapped[bool] = mapped_column(Boolean, default=False)
    description: Mapped[str] = mapped_column(Text, default="")
    verified: Mapped[bool] = mapped_column(Boolean, default=False)

class Course(Base):
    __tablename__="courses"
    id: Mapped[str] = mapped_column(String(40), primary_key=True)
    name: Mapped[str] = mapped_column(String(120), index=True)
    degree: Mapped[str] = mapped_column(String(120))
    duration: Mapped[str] = mapped_column(String(80))
    eligibility: Mapped[str] = mapped_column(Text)
    description: Mapped[str] = mapped_column(Text, default="")

class Scholarship(Base):
    __tablename__="scholarships"
    id: Mapped[str] = mapped_column(String(40), primary_key=True)
    name: Mapped[str] = mapped_column(String(200))
    provider: Mapped[str] = mapped_column(String(150))
    category: Mapped[str] = mapped_column(String(80))
    amount: Mapped[str] = mapped_column(String(100))
    eligibility: Mapped[str] = mapped_column(Text)
    deadline: Mapped[str] = mapped_column(String(100))
    official_link: Mapped[str] = mapped_column(String(500))

class Lead(Base):
    __tablename__="leads"
    id: Mapped[str] = mapped_column(String(40), primary_key=True)
    name: Mapped[str] = mapped_column(String(150))
    mobile: Mapped[str] = mapped_column(String(30))
    email: Mapped[Optional[str]] = mapped_column(String(200), nullable=True)
    course: Mapped[str] = mapped_column(String(120))
    college: Mapped[Optional[str]] = mapped_column(String(200), nullable=True)
    source: Mapped[str] = mapped_column(String(80), default="website")
    status: Mapped[str] = mapped_column(String(60), default="New")
    notes: Mapped[str] = mapped_column(Text, default="")
    created_at: Mapped[dt.datetime] = mapped_column(DateTime, default=dt.datetime.utcnow)

Base.metadata.create_all(engine)

def seed():
    with SessionLocal() as s:
        if not s.scalar(select(College).limit(1)):
            data=[
              ("COLLEGE000001","Alvas Homoeopathic Medical College","Mangaluru","Karnataka","BHMS",145000,4.7,"Private",True),
              ("COLLEGE000002","Seemanchal Institute of Health Sciences","Araria","Bihar","BAMS",165000,4.3,"Private",True),
              ("COLLEGE000003","TechNova Institute of Technology","Bengaluru","Karnataka","BCA",95000,4.5,"Private",False),
              ("COLLEGE000004","National School of Business","Bengaluru","Karnataka","MBA",180000,4.6,"Private",True),
              ("COLLEGE000005","Government Medical College","Patna","Bihar","MBBS",85000,4.8,"Government",False),
            ]
            for x in data:
                s.add(College(id=x[0],name=x[1],city=x[2],state=x[3],course=x[4],fees=x[5],rating=x[6],college_type=x[7],hostel=x[8],verified=True,description="Demo database record — verify current information with the institution."))
        if not s.scalar(select(Course).limit(1)):
            for x in [
                ("COURSE000001","BHMS","Bachelor of Homoeopathic Medicine and Surgery","5.5 years","As applicable to current regulatory/admission rules."),
                ("COURSE000002","BAMS","Bachelor of Ayurvedic Medicine and Surgery","5.5 years","As applicable to current regulatory/admission rules."),
                ("COURSE000003","BCA","Bachelor of Computer Applications","3 years","Typically requires 12th qualification; verify institution rules."),
                ("COURSE000004","MBA","Master of Business Administration","2 years","Typically requires a bachelor's degree; verify institution rules."),
                ("COURSE000005","MBBS","Bachelor of Medicine and Bachelor of Surgery","5.5 years","As applicable to current regulatory/admission rules.")
            ]:
                s.add(Course(id=x[0],name=x[1],degree=x[2],duration=x[3],eligibility=x[4],description="Course information should be verified against current official sources."))
        if not s.scalar(select(Scholarship).limit(1)):
            for x in [
                ("SCH000001","National Scholarship Portal","Government","Government","Varies","Eligibility varies by scheme.","Check official portal","https://scholarships.gov.in/"),
                ("SCH000002","Merit Scholarship","Padhaanewala","Merit","Up to ₹50,000","Illustrative MVP listing; verify eligibility.","Rolling","#"),
                ("SCH000003","Future Leaders Scholarship","Private","Private","Up to ₹25,000","Illustrative MVP listing; verify eligibility.","Rolling","#")
            ]:
                s.add(Scholarship(id=x[0],name=x[1],provider=x[2],category=x[3],amount=x[4],eligibility=x[5],deadline=x[6],official_link=x[7]))
        s.commit()
seed()

app=FastAPI(title="Padhaanewala API", version="1.0")
app.add_middleware(CORSMiddleware,allow_origins=["*"],allow_credentials=True,allow_methods=["*"],allow_headers=["*"])

class LeadIn(BaseModel):
    name:str
    mobile:str
    email:Optional[EmailStr]=None
    course:str
    college:Optional[str]=None
    source:str="website"
    message:Optional[str]=""

class LoginIn(BaseModel):
    email:EmailStr
    password:str

class PredictorIn(BaseModel):
    course:str
    budget:float
    state:str=""
    city:str=""
    government:Optional[bool]=None
    hostel:bool=False
    rank:Optional[int]=None

def admin_token():
    return jwt.encode({"sub":ADMIN_EMAIL,"role":"super_admin","exp":dt.datetime.utcnow()+dt.timedelta(hours=12)},JWT_SECRET,algorithm="HS256")

def require_admin(authorization: Optional[str]=Header(None)):
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(401,"Admin authentication required")
    try:
        p=jwt.decode(authorization[7:],JWT_SECRET,algorithms=["HS256"])
        if p.get("role")!="super_admin": raise HTTPException(403,"Forbidden")
        return p
    except JWTError: raise HTTPException(401,"Invalid token")

@app.get("/api/v1/health")
def health(): return {"status":"ok","service":"Padhaanewala API"}

@app.post("/api/v1/auth/admin/login")
def login(x:LoginIn):
    if x.email.lower()!=ADMIN_EMAIL.lower() or x.password!=ADMIN_PASSWORD:
        raise HTTPException(401,"Invalid credentials")
    return {"access_token":admin_token(),"token_type":"bearer"}

@app.get("/api/v1/colleges")
def colleges(q:str="",course:str="",state:str="",city:str="",max_fee:float=10**9,limit:int=50):
    with SessionLocal() as s:
        stmt=select(College)
        terms=[]
        if q: terms += [College.name.ilike(f"%{q}%"),College.city.ilike(f"%{q}%"),College.state.ilike(f"%{q}%"),College.course.ilike(f"%{q}%")]
        if terms: stmt=stmt.where(or_(*terms))
        if course: stmt=stmt.where(College.course.ilike(f"%{course}%"))
        if state: stmt=stmt.where(College.state.ilike(f"%{state}%"))
        if city: stmt=stmt.where(College.city.ilike(f"%{city}%"))
        stmt=stmt.where(College.fees<=max_fee).limit(min(limit,100))
        rows=s.scalars(stmt).all()
        return [row.__dict__ | {"_sa_instance_state":None} for row in rows]

@app.get("/api/v1/colleges/{college_id}")
def college(college_id:str):
    with SessionLocal() as s:
        x=s.get(College,college_id)
        if not x: raise HTTPException(404,"College not found")
        return {k:v for k,v in x.__dict__.items() if k!="_sa_instance_state"}

@app.get("/api/v1/courses")
def courses():
    with SessionLocal() as s:
        return [{k:v for k,v in x.__dict__.items() if k!="_sa_instance_state"} for x in s.scalars(select(Course)).all()]

@app.get("/api/v1/scholarships")
def scholarships():
    with SessionLocal() as s:
        return [{k:v for k,v in x.__dict__.items() if k!="_sa_instance_state"} for x in s.scalars(select(Scholarship)).all()]

@app.post("/api/v1/enquiries")
def enquiry(x:LeadIn):
    with SessionLocal() as s:
        lead=Lead(id="LEAD"+uuid.uuid4().hex[:12].upper(),name=x.name,mobile=x.mobile,email=str(x.email) if x.email else None,course=x.course,college=x.college,source=x.source,notes=x.message or "")
        s.add(lead); s.commit()
        return {"success":True,"lead_id":lead.id,"message":"Thank you. Our counsellor will contact you."}

@app.post("/api/v1/predictor")
def predictor(x:PredictorIn):
    with SessionLocal() as s:
        rows=s.scalars(select(College).where(College.course.ilike(f"%{x.course}%"),College.fees<=x.budget)).all()
        scored=[]
        for c in rows:
            score=50
            if x.state and c.state.lower()==x.state.lower(): score+=20
            if x.city and c.city.lower()==x.city.lower(): score+=10
            if x.government is not None and ((x.government and c.college_type=="Government") or (not x.government and c.college_type=="Private")): score+=10
            if x.hostel and c.hostel: score+=10
            scored.append((score,c))
        scored.sort(key=lambda z:(-z[0],-z[1].rating))
        return {"disclaimer":"Estimates only. This is not an admission guarantee. Verify current eligibility, fees, seats and counselling rules with official sources.","results":[{"match_score":min(99,sc),"category":"Highly Suitable" if sc>=80 else "Possible" if sc>=65 else "Reach","college":{k:v for k,v in c.__dict__.items() if k!="_sa_instance_state"}} for sc,c in scored[:10]]}

@app.get("/api/v1/admin/stats")
def stats(_=Depends(require_admin)):
    with SessionLocal() as s:
        return {"colleges":s.query(College).count(),"courses":s.query(Course).count(),"scholarships":s.query(Scholarship).count(),"leads":s.query(Lead).count()}

@app.get("/api/v1/admin/leads")
def admin_leads(_=Depends(require_admin)):
    with SessionLocal() as s:
        return [{k:v for k,v in x.__dict__.items() if k!="_sa_instance_state"} for x in s.scalars(select(Lead).order_by(Lead.created_at.desc())).all()]

@app.post("/api/v1/admin/colleges")
def admin_add_college(x:dict,_=Depends(require_admin)):
    with SessionLocal() as s:
        c=College(id=x.get("id") or "COLLEGE"+uuid.uuid4().hex[:12].upper(),name=x["name"],city=x.get("city",""),state=x.get("state",""),course=x.get("course",""),fees=float(x.get("fees",0)),rating=float(x.get("rating",0)),college_type=x.get("college_type","Private"),hostel=bool(x.get("hostel",False)),description=x.get("description",""),verified=bool(x.get("verified",False)))
        s.add(c); s.commit()
        return {"success":True,"id":c.id}

@app.patch("/api/v1/admin/leads/{lead_id}")
def update_lead(lead_id:str,x:dict,_=Depends(require_admin)):
    with SessionLocal() as s:
        lead=s.get(Lead,lead_id)
        if not lead: raise HTTPException(404,"Lead not found")
        if "status" in x: lead.status=x["status"]
        if "notes" in x: lead.notes=x["notes"]
        s.commit()
        return {"success":True}

@app.get("/api/v1/admin/colleges")
def admin_colleges(_=Depends(require_admin)):
    return colleges(limit=100)
