"use client";
import {useEffect,useState} from "react";
import {LayoutDashboard,Building2,Users,GraduationCap,LogOut,Plus,ShieldCheck} from "lucide-react";
import "../styles.css";

const API=process.env.NEXT_PUBLIC_API_URL||"http://localhost:8000/api/v1";

export default function Admin(){
 const [token,setToken]=useState(typeof window!=="undefined"?localStorage.getItem("pn_admin"):null);
 const [email,setEmail]=useState("admin@padhaanewala.in"),[password,setPassword]=useState("admin123"),[error,setError]=useState("");
 const [stats,setStats]=useState(null),[leads,setLeads]=useState([]);
 async function login(e){e.preventDefault();const r=await fetch(API+"/auth/admin/login",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({email,password})});const x=await r.json();if(!r.ok){setError(x.detail||"Login failed");return}localStorage.setItem("pn_admin",x.access_token);setToken(x.access_token)}
 useEffect(()=>{if(token){fetch(API+"/admin/stats",{headers:{Authorization:"Bearer "+token}}).then(r=>r.json()).then(setStats);fetch(API+"/admin/leads",{headers:{Authorization:"Bearer "+token}}).then(r=>r.json()).then(setLeads)}},[token]);
 if(!token)return <main className="adminLogin"><div className="adminBox"><div className="brand"><span className="logo">P</span> Padhaanewala Admin</div><h1>Welcome back.</h1><p>Manage colleges, content and admission leads.</p><form onSubmit={login}><input value={email} onChange={e=>setEmail(e.target.value)} placeholder="Email"/><input value={password} onChange={e=>setPassword(e.target.value)} type="password" placeholder="Password"/><button className="btn primary">Sign in</button>{error&&<div className="success" style={{background:"#ffe3e3",color:"#a22"}}>{error}</div>}</form><small>Demo: admin@padhaanewala.in / admin123 — change before production.</small></div></main>;
 return <main><nav className="nav"><div className="brand"><span className="logo">P</span> Admin</div><div className="links"><a><LayoutDashboard/> Dashboard</a><a><Building2/> Colleges</a><a><GraduationCap/> Courses</a><a><Users/> Leads</a></div><button className="btn" onClick={()=>{localStorage.removeItem("pn_admin");setToken(null)}}><LogOut/> Logout</button></nav><section className="section page"><div className="eyebrow">CONTROL CENTER</div><h2>Padhaanewala Admin</h2><div className="featureGrid" style={{marginTop:30}}>{[["Colleges",stats?.colleges||0],["Courses",stats?.courses||0],["Scholarships",stats?.scholarships||0],["Admission Leads",stats?.leads||0]].map(x=><div className="card" key={x[0]}><div className="eyebrow">{x[0]}</div><h2>{x[1]}</h2></div>)}</div><div className="sectionHead" style={{marginTop:60}}><h2>Latest leads</h2></div><div className="card" style={{overflowX:"auto"}}><table style={{width:"100%",borderCollapse:"collapse"}}><thead><tr><th align="left">Student</th><th align="left">Course</th><th align="left">Mobile</th><th align="left">Status</th><th align="left">Source</th></tr></thead><tbody>{leads.map(l=><tr key={l.id}><td>{l.name}</td><td>{l.course}</td><td>{l.mobile}</td><td>{l.status}</td><td>{l.source}</td></tr>)}</tbody></table></div></section></main>
}
